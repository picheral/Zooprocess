import ij.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.*;

public class free_memory implements PlugIn {

	public void run(String arg) {
        		 IJ.freeMemory();
                }

}
